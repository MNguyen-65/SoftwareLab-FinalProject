# SoftwareLab-FinalProject

## Login Screen HTML user inputs (as named by Flask backend)
Username, Password

## The URL routes that we use are:
/login
/add_user
/check_in
/check_out

## Hardware checkin and checkout
Username, HardwareItem, Quantity

